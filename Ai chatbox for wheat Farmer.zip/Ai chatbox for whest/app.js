const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const dotenv = require("dotenv");
const OpenAI = require("openai");

// --- Load environment variables ---
dotenv.config();

const app = express();
app.use(express.json());

// ✅ Serve static frontend files (JS, CSS, images)
app.use(express.static(path.join(__dirname, "static")));

// --- OpenAI setup ---
const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// --- Database setup (SQLite) ---
const DB_PATH = path.join(__dirname, "wheat.db");
const db = new sqlite3.Database(DB_PATH);

// ✅ Create chat_history table if not exists
db.run(`
  CREATE TABLE IF NOT EXISTS chat_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_message TEXT,
    ai_reply TEXT
  )
`);

// --- Routes ---

// ✅ Serve the main HTML file
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "templates", "login" , "index.html"));
});

// ✅ Handle chat requests from frontend
app.post("/ask", async (req, res) => {
  const userInput = req.body.message;

  if (!userInput) {
    return res.status(400).json({ error: "Missing message field" });
  }

  try {
    // Step 1: Ask OpenAI
    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content:
            "You are WheatAI, an agriculture expert for wheat farmers in India. Answer questions clearly, simply, and naturally like a helpful human assistant.",
        },
        { role: "user", content: userInput },
      ],
    });

    const aiReply = response.choices[0].message.content;

    // Step 2: Save chat to SQLite
    db.run(
      "INSERT INTO chat_history (user_message, ai_reply) VALUES (?, ?)",
      [userInput, aiReply],
      (err) => {
        if (err) console.error("Database insert error:", err);
      }
    );

    // Step 3: Return AI response to frontend
    res.json({ reply: aiReply });
  } catch (error) {
    console.error("Error communicating with OpenAI:", error);
    res.status(500).json({ error: "Failed to get AI response" });
  }
});

// --- Start server ---
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Server running on http://localhost:${PORT}`));
