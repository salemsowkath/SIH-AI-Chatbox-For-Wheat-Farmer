sessionStorage.setItem("isLoggedIn", "true");
function logoutUser() {
  sessionStorage.removeItem("isLoggedIn");
  window.location.href = "../../login/index.html";
}
