// Handle Login Form
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    if (username === "admin" && password === "1234") {
      sessionStorage.setItem("isLoggedIn", "true");
      alert("Login successful ✔️");
      window.location.href = "D:/Ai chatbox for whest/templates/ai/index.html";
    } else {
      alert("Invalid credentials ❌");
    }
  });
}

// Handle Signup Form
const signupForm = document.getElementById("signupForm");
if (signupForm) {
  signupForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const newUsername = document.getElementById("newUsername").value.trim();
    const newEmail = document.getElementById("newEmail").value.trim();
    const newPassword = document.getElementById("newPassword").value.trim();

    if (newUsername && newEmail && newPassword) {
      alert("Account created successfully ✔️");
      window.location.href = "index.html";
    } else {
      alert("Please fill in all fields ❗");
    }
  });
}

// Handle Forgot Password Form
const forgotForm = document.getElementById("forgotForm");
if (forgotForm) {
  forgotForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const resetEmail = document.getElementById("resetEmail").value.trim();

    if (resetEmail) {
      alert(`Password reset link sent to ${resetEmail} 📧`);
      window.location.href = "index.html";
    } else {
      alert("Please enter your email ❗");
    }
  });
  

}

document.querySelectorAll('.social-login button').forEach(btn => {
  btn.addEventListener('click', e => {
    e.preventDefault();
    alert(`${btn.textContent.trim()} — Coming Soon 🚀`);
  });
});
